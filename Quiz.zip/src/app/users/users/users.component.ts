import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  form: any = [];

  constructor(private router:Router, private toastr: ToastrService) { }

  ngOnInit() {
  }

  guardarUsuario(){
    if(this.form.nombres != null && this.form.correo !=null){
      localStorage.setItem("nombre",this.form.nombres);
      localStorage.setItem("correo",this.form.correo);
        this.router.navigate(['quiz']); 
    }else{
        this.toastr.warning("Los datos son obligatorios");
    }
  }

}
