import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agradecimiento',
  templateUrl: './agradecimiento.component.html',
  styleUrls: ['./agradecimiento.component.css']
})
export class AgradecimientoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
